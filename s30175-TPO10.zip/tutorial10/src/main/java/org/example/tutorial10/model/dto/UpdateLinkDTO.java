package org.example.tutorial10.model.dto;

public class UpdateLinkDTO {
    public String name;
    public String password;
    public String targetUrl;
}
