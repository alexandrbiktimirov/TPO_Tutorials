package org.example.tutorial10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tutorial10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
